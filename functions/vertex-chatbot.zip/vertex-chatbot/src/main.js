import { VertexAI } from '@google-cloud/vertexai';
import { Client, Databases, ID, Query } from 'node-appwrite';

export default async ({ req, res, log, error }) => {
  log("Function executed");

  if (req.method === 'GET') {
    return res.send("HUGS STUDIO Vertex AI Chatbot Service is running.");
  }

  try {
    const payload = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
    const { history = [], message, sessionId } = payload;

    if (!message) {
      return res.json({ error: "Message is required" }, 400);
    }

    // ── Google Cloud Vertex AI Setup ──
    const gcpProjectId = process.env.GOOGLE_CLOUD_PROJECT_ID;
    const gcpLocation = process.env.GOOGLE_CLOUD_LOCATION || 'us-central1';
    const saJson = process.env.GOOGLE_SERVICE_ACCOUNT_JSON;
    
    if (!gcpProjectId || !saJson) {
      error("Missing configuration: GOOGLE_CLOUD_PROJECT_ID or GOOGLE_SERVICE_ACCOUNT_JSON");
      return res.json({ error: "Server configuration missing" }, 500);
    }

    let credentials;
    try {
      credentials = JSON.parse(saJson);
    } catch (e) {
      error("Failed to parse Service Account JSON: " + e.message);
      return res.json({ error: "Invalid Service Account configuration" }, 500);
    }

    // Inject credentials directly into VertexAI constructor
    const vertexAI = new VertexAI({ 
      project: gcpProjectId, 
      location: gcpLocation,
      googleAuthOptions: { credentials }
    });
    
    // Using gemini-1.5-flash-001 (standard Vertex model ID)
    const modelId = 'gemini-1.5-flash-001';
    
    const systemInstruction = `Bạn là nhân viên Lễ tân của HUGs STUDIO — một studio chuyên nghiệp tại Việt Nam.
BẠN PHẢI LUÔN TRẢ LỜI BẰNG TIẾNG VIỆT.
NHÂN CÁCH: "em", gọi khách "Anh/Chị", thân thiện, chuyên nghiệp.
CÁCH TƯ VẤN: Lắng nghe, xin TÊN, SĐT, EMAIL khéo léo sau khi hiểu nhu cầu.
Khi có thông tin, gắn kèm: <!--CUSTOMER_INFO:{"name":"Tên","phone":"SĐT","email":"Email"}--> ở cuối`;

    const generativeModel = vertexAI.getGenerativeModel({
      model: modelId,
      systemInstruction: { role: 'system', parts: [{ text: systemInstruction }] },
      generationConfig: { maxOutputTokens: 1000, temperature: 0.7 }
    });

    const formattedHistory = history
      .filter((msg, i) => !(i === 0 && msg.role === "assistant"))
      .map(msg => ({
        role: msg.role === "assistant" ? "model" : "user",
        parts: [{ text: msg.content || "" }]
      }));

    log("Calling Vertex AI model: " + modelId);
    
    try {
      const chat = generativeModel.startChat({ history: formattedHistory });
      const result = await chat.sendMessage([{ text: message }]);
      const response = result.response;
      
      log("Response received from Vertex AI");

      let rawReply = "";
      if (response.candidates && response.candidates[0] && response.candidates[0].content && response.candidates[0].content.parts) {
        rawReply = response.candidates[0].content.parts[0].text || "";
      }

      if (!rawReply) {
        log("No text in parts, checking response.text()");
        try { rawReply = response.text() || ""; } catch(e) { log("response.text() failed: " + e.message); }
      }

      if (!rawReply) {
        log("WARNING: Empty reply. Check Safety Filters.");
        log("Safety: " + JSON.stringify(response.candidates[0]?.safetyRatings || []));
        rawReply = "Dạ em rất tiếc, câu hỏi này của Anh/Chị gặp vấn đề về bảo mật nội dung nên em không thể trả lời được ạ. Anh/Chị có câu hỏi nào khác không?";
      }

      // ── Extract Info ──
      const regex = /<!--CUSTOMER_INFO:([\s\S]*?)-->/;
      const match = rawReply.match(regex);
      let cleanReply = rawReply;
      let info = null;
      
      if (match) {
        try {
          info = JSON.parse(match[1]);
          cleanReply = rawReply.replace(regex, "").trim();
        } catch (e) { log("Failed to parse info"); }
      }

      // ── Save to Appwrite Database ──
      if (sessionId) {
        try {
          const client = new Client()
            .setEndpoint(process.env.APPWRITE_FUNCTION_ENDPOINT)
            .setProject(process.env.APPWRITE_FUNCTION_PROJECT_ID)
            .setKey(process.env.APPWRITE_API_KEY);

          const databases = new Databases(client);
          const dbId = process.env.APPWRITE_DATABASE_ID || "69ba2ae900156b378b6b";
          const collId = "chat_leads";

          const docs = await databases.listDocuments(dbId, collId, [
            Query.equal("session_id", sessionId),
            Query.limit(1)
          ]);

          const fullHistory = [...history, { role: "user", content: message }, { role: "assistant", content: cleanReply }];
          const conversationJson = JSON.stringify(fullHistory.slice(-50));

          if (docs.total > 0) {
            const docId = docs.documents[0].$id;
            const updates = { conversation: conversationJson };
            if (info?.name) updates.name = info.name;
            if (info?.phone) updates.phone = info.phone;
            if (info?.email) updates.email = info.email;
            await databases.updateDocument(dbId, collId, docId, updates);
          } else {
            await databases.createDocument(dbId, collId, ID.unique(), {
              session_id: sessionId,
              name: info?.name || "",
              phone: info?.phone || "",
              email: info?.email || "",
              conversation: conversationJson,
              status: "new"
            });
          }
        } catch (dbErr) {
          error("Appwrite DB Error: " + dbErr.message);
        }
      }

      return res.json({ reply: cleanReply });

    } catch (aiErr) {
      error("Vertex AI Communication Error: " + aiErr.message);
      return res.json({ error: "Gemini Vertex AI failed: " + aiErr.message }, 500);
    }

  } catch (err) {
    error("General Function Error: " + err.message);
    return res.json({ error: "Internal function error" }, 500);
  }
};
